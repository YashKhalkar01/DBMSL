# DBMS-Practicals
This repo contains code of DBMS Practicals SPPU 
